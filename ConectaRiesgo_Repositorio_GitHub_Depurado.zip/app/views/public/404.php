<section class="page"><h1>404</h1><p>La página solicitada no existe.</p><a class="btn primary" href="<?=e(url('/'))?>">Volver al inicio</a></section>
