<section class="page"><span class="eyebrow">REPORTE CIUDADANO</span><h1>Reportar mi sector</h1><p>Registra una afectación. No incluyas información médica sensible ni datos personales de terceros en la descripción.</p><form method="post" enctype="multipart/form-data" class="form" data-gps-form><input type="hidden" name="_token" value="<?=e(csrf_token())?>"><label>Sector<select name="zone_id" required><option value="">Selecciona...</option><?php foreach($zones as $z):?><option value="<?=e((string)$z['id'])?>"><?=e($z['name'])?></option><?php endforeach;?></select></label><label>Nivel de afectación<select name="severity" required><option value="light">Leve</option><option value="moderate">Moderada</option><option value="severe">Severa</option><option value="critical">Crítica</option></select></label><fieldset><legend>Indicadores</legend><label><input type="checkbox" name="indicators[]" value="homes_affected"> Viviendas afectadas</label><label><input type="checkbox" name="indicators[]" value="road_blocked"> Vías bloqueadas</label><label><input type="checkbox" name="indicators[]" value="people_isolated"> Personas aisladas</label><label><input type="checkbox" name="indicators[]" value="services_down"> Servicios interrumpidos</label></fieldset><label>Descripción<textarea name="description" rows="5" maxlength="1200" placeholder="Describe brevemente la situación"></textarea></label><fieldset><legend>Foto de la afectación (opcional)</legend>
<p>Adjunta una foto del sector o zona afectada. JPG, PNG o WebP, hasta 5 MB y 12 megapíxeles. La foto podrá verse al consultar el código del caso.</p>
<?php if(!empty($photoError)):?><p role="alert"><?=e($photoError)?></p><?php endif;?>
<label>Seleccionar foto<input type="file" name="photo" accept="image/jpeg,image/png,image/webp" data-report-photo></label>
<p data-photo-status role="status" aria-live="polite"></p>
<img data-photo-preview alt="Vista previa de la foto seleccionada" hidden style="max-width:100%;max-height:320px;object-fit:contain">
<p>Evita incluir rostros, documentos o información personal.</p></fieldset>
<?php require __DIR__.'/location.php'; ?><button class="btn primary">Enviar reporte</button></form></section>

<script src="<?=e(url('/assets/js/location.js?v=1'))?>" defer></script>

<script src="<?=e(url('/assets/js/report-photo.js?v=1'))?>" defer></script>
