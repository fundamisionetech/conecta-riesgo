<?php
$caseStatusLabels = [
 'received'=>'Recibida',
 'pending_verification'=>'Pendiente de verificación',
 'verified'=>'Verificada',
 'assigned'=>'Asignada',
 'help_on_way'=>'Ayuda en camino',
 'attended'=>'Atendida',
 'closed'=>'Cerrada',
 'duplicate'=>'Duplicada',
 'unverifiable'=>'No verificable',
 'cancelled'=>'Cancelada',
];
?>
<section class="page"><span class="eyebrow">SEGUIMIENTO</span><h1>Consulta tu caso</h1><?php if($m=flash('success')):?><div class="notice ok" role="status"><?php if($result && str_starts_with($result['code'],'AY-')):?>Tu solicitud fue registrada y pasará a verificación antes de ser asignada a una organización.<?php else:?><?=e($m)?><?php endif;?></div><?php endif;?><form method="post" class="inline-form"><input type="hidden" name="_token" value="<?=e(csrf_token())?>"><input name="code" value="<?=e($code??'')?>" placeholder="CR-BAB-... o AY-BAB-..." required><button class="btn primary">Consultar</button></form><?php if(isset($code)&&$code!==''&&!$result):?><div class="notice">No encontramos un caso con ese código.</div><?php endif;?><?php if($result):?><article class="case"><div class="case-head"><div><small>CÓDIGO</small><h2><?=e($result['code'])?></h2><?php if(str_starts_with($result['code'],'AY-')):?><p style="margin:8px 0 0;max-width:560px;line-height:1.5">Guárdalo o tómale una foto; con él puedes consultar el estado sin crear una cuenta.</p><?php endif;?></div><span class="badge"><?=e($caseStatusLabels[$result['status']]??'Estado no disponible')?></span></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px"><style>.case small{display:block;margin-bottom:6px}</style><div><small>Sector</small><b><?=e($result['zone_name']??'No especificado')?></b></div><div><small>Última actualización</small><b><?=e($result['updated_at']??$result['reported_at']??$result['requested_at']??'')?></b></div></div><?php if(!empty($result['photo_path']) && str_starts_with($result['code'],'CR-')):?><h3>Foto de la afectación</h3><a href="<?=e(url('/foto').'?code='.rawurlencode($result['code']))?>" target="_blank" rel="noopener"><img src="<?=e(url('/foto').'?code='.rawurlencode($result['code']))?>" alt="Foto de la zona afectada" loading="lazy" style="display:block;max-width:100%;max-height:420px;object-fit:contain"></a><?php endif;?></article><?php endif;?></section>
