'use strict';
document.querySelectorAll('[data-gps-form]').forEach(form => {
  const button = form.querySelector('[data-get-location]');
  const status = form.querySelector('[data-location-status]');
  const latitude = form.elements.latitude;
  const longitude = form.elements.longitude;
  const confirmed = form.elements.location_confirmed;
  let acquiredAt = 0;
  function clearLocation() {
    latitude.value = ''; longitude.value = '';
    confirmed.checked = false; confirmed.disabled = true; acquiredAt = 0;
  }
  button.addEventListener('click', () => {
    clearLocation();
    if (!window.isSecureContext) {
      status.textContent = 'Abre el sitio mediante HTTPS para obtener la ubicación.'; return;
    }
    if (!navigator.geolocation) {
      status.textContent = 'Este navegador no permite obtener ubicación. Usa otro dispositivo.'; return;
    }
    button.disabled = true;
    status.textContent = 'Obteniendo ubicación… Permite el acceso cuando lo solicite el navegador.';
    navigator.geolocation.getCurrentPosition(position => {
      button.disabled = false;
      const c = position.coords;
      if (!Number.isFinite(c.latitude) || !Number.isFinite(c.longitude) || c.latitude < -90 || c.latitude > 90 || c.longitude < -180 || c.longitude > 180) {
        status.textContent = 'La ubicación recibida no es válida. Intenta nuevamente.'; return;
      }
      latitude.value = c.latitude.toFixed(7);
      longitude.value = c.longitude.toFixed(7);
      acquiredAt = Date.now();
      confirmed.disabled = false;
      const accuracy = Number.isFinite(c.accuracy) ? Math.ceil(c.accuracy) : null;
      status.textContent = 'Ubicación obtenida: ' + latitude.value + ', ' + longitude.value +
        (accuracy !== null ? '. Margen de precisión estimado: ±' + accuracy + ' metros.' : '.') +
        (accuracy !== null && accuracy > 100 ? ' La precisión es baja; vuelve a intentar desde un celular con ubicación activada.' : '') +
        ' Confirma que estás en el lugar del caso.';
    }, error => {
      button.disabled = false; clearLocation();
      status.textContent = ({
        1: 'Permiso de ubicación denegado. Habilítalo en el navegador y vuelve a intentar.',
        2: 'Ubicación no disponible. Activa la ubicación del dispositivo y vuelve a intentar.',
        3: 'Se agotó el tiempo de búsqueda. Vuelve a intentar.'
      })[error.code] || 'No fue posible obtener la ubicación. Vuelve a intentar.';
    }, {enableHighAccuracy: true, timeout: 30000, maximumAge: 0});
  });
  form.addEventListener('submit', event => {
    if (!acquiredAt || Date.now() - acquiredAt > 600000 || !confirmed.checked) {
      event.preventDefault();
      status.textContent = 'Obtén una ubicación reciente y confirma que corresponde al lugar del caso antes de enviar.';
      button.focus();
    }
  });
});
