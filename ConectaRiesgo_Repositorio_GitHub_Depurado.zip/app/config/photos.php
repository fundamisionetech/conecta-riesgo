<?php
declare(strict_types=1);
function store_report_photo(): ?string {
 $f=$_FILES['photo']??null;
 if (!$f || ($f['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) return null;
 if(!is_array($f) || ($f['error']??-1)!==UPLOAD_ERR_OK || !is_string($f['tmp_name']??null) || !is_uploaded_file($f['tmp_name'])) throw new RuntimeException('No se pudo subir la foto. Intenta con otra imagen.');
 if(filesize($f['tmp_name'])>5*1024*1024) throw new RuntimeException('La foto debe pesar como máximo 5 MB.');
 $info=@getimagesize($f['tmp_name']);
 $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
 if(!$info || !in_array($mime,['image/jpeg','image/png','image/webp'],true) || ($info['mime']??'')!==$mime) throw new RuntimeException('Adjunta una imagen JPG, PNG o WebP válida.');
 if($info[0]>8000 || $info[1]>8000 || $info[0]*$info[1]>12000000) throw new RuntimeException('La foto es demasiado grande. Usa una versión de hasta 12 megapíxeles.');
 if(!function_exists('imagecreatefromstring')) throw new RuntimeException('La carga de fotos requiere activar la extensión GD en el hosting.');
 $image=@imagecreatefromstring(file_get_contents($f['tmp_name']));
 if(!$image) throw new RuntimeException('No se pudo procesar la imagen.');
 $dir=dirname(__DIR__,2).'/storage/uploads/reports';
 if(!is_dir($dir) && !mkdir($dir,0750,true)) throw new RuntimeException('No se pudo preparar la carpeta de fotos.');
 $relative='reports/'.bin2hex(random_bytes(20)).'.jpg';
 $path=dirname(__DIR__,2).'/storage/uploads/'.$relative;
 // Reencodificar elimina metadatos y contenido adicional del archivo original.
 $canvas=imagecreatetruecolor($info[0],$info[1]);
 imagefill($canvas,0,0,imagecolorallocate($canvas,255,255,255));
 imagecopy($canvas,$image,0,0,0,0,$info[0],$info[1]);
 $ok=imagejpeg($canvas,$path,85);
 imagedestroy($canvas); imagedestroy($image);
 if(!$ok) throw new RuntimeException('No se pudo guardar la foto. Revisa los permisos de la carpeta.');
 chmod($path,0640);
 return $relative;
}
function reportPhoto(): never {
 $code=$_GET['code']??'';
 if(!is_string($code) || strlen($code)>80){http_response_code(404);exit;}
 $q=db()->prepare('SELECT photo_path FROM reports WHERE code=?');$q->execute([$code]);
 $relative=$q->fetchColumn();
 if(!is_string($relative) || !preg_match('~^reports/[a-f0-9]{40}\\.jpg$~D',$relative)){http_response_code(404);exit;}
 $path=dirname(__DIR__,2).'/storage/uploads/'.$relative;
 if(!is_file($path)){http_response_code(404);exit;}
 header('Content-Type: image/jpeg');header('X-Content-Type-Options: nosniff');
 header('Cache-Control: private, max-age=300');header('Content-Length: '.filesize($path));
 readfile($path);exit;
}
