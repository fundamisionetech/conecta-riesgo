<?php
declare(strict_types=1);
require __DIR__ . '/app/config/bootstrap.php';
require __DIR__ . '/app/config/photos.php';

$uriPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$basePath = base_path();
if ($basePath !== '' && str_starts_with($uriPath, $basePath)) {
    $uriPath = substr($uriPath, strlen($basePath)) ?: '/';
}
$path = '/' . ltrim($uriPath, '/');
if ($path !== '/' && str_ends_with($path, '/')) $path = rtrim($path, '/');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

$routes = [
 'GET' => [
  '/foto' => 'reportPhoto',
  '/' => 'home', '/reportar' => 'reportForm', '/ayuda' => 'helpForm', '/consultar' => 'trackForm',
  '/alertas' => 'alerts', '/puntos' => 'points', '/mapa' => 'map', '/login' => 'loginForm',
  '/logout' => 'logout', '/panel' => 'dashboard', '/panel/reportes' => 'panelReports', '/panel/solicitudes' => 'panelNeeds',
  '/recursos' => 'resources'
 ],
 'POST' => [ '/reportar' => 'reportStore', '/ayuda' => 'helpStore', '/consultar' => 'track', '/login' => 'login' ]
];
$action = $routes[$method][$path] ?? null;
if (!$action || !function_exists($action)) { http_response_code(404); view('public/404'); }
$action();

function home(): void { view('public/home'); }
function resources(): void { view('public/resources'); }
function reportForm(): void {
 $zones=db()->query("SELECT id,name FROM zones WHERE active=1 ORDER BY name")->fetchAll();
 view('public/report', compact('zones'));
}
function reportStore(): void {
 if(empty($_POST) && (int)($_SERVER['CONTENT_LENGTH']??0)>0){
  http_response_code(413);
  $photoError='El envío supera el límite del hosting. Usa una foto más pequeña y vuelve a completar el formulario.';
  $zones=db()->query("SELECT id,name FROM zones WHERE active=1 ORDER BY name")->fetchAll();
  view('public/report',compact('zones','photoError'));
 }
 verify_csrf();
 [$latitude,$longitude]=require_location('public/report');
 $pdo=db();
 try { $photo=store_report_photo(); }
 catch(RuntimeException $ex){
  http_response_code(422);
  $photoError=$ex->getMessage();
  $zones=db()->query("SELECT id,name FROM zones WHERE active=1 ORDER BY name")->fetchAll();
  view('public/report',compact('zones','photoError'));
 }
 try {
 $pdo->beginTransaction();
 $code=generate_code('CR-BAB');
 $stmt=db()->prepare("INSERT INTO reports(code,zone_id,severity,indicators,description,latitude,longitude,photo_path,status,verification,reported_at) VALUES(?,?,?,?,?,?,?,?,'pending_verification','citizen',NOW())");
 $stmt->execute([$code,$_POST['zone_id']?:null,$_POST['severity'],json_encode($_POST['indicators']??[], JSON_UNESCAPED_UNICODE),trim($_POST['description']??''),$latitude,$longitude,$photo]);
 $id=(int)db()->lastInsertId();
 db()->prepare("INSERT INTO report_updates(report_id,to_status,comment,created_at) VALUES(?,'pending_verification','Reporte ciudadano recibido',NOW())")->execute([$id]);
 $pdo->commit();
 } catch(Throwable $ex) {
  if($pdo->inTransaction()) $pdo->rollBack();
  if($photo) @unlink(__DIR__.'/storage/uploads/'.$photo);
  error_log('No se pudo guardar reporte: '.$ex->getMessage());
  http_response_code(500);
  $photoError='No se pudo guardar el reporte. Intenta nuevamente.';
  $zones=db()->query("SELECT id,name FROM zones WHERE active=1 ORDER BY name")->fetchAll();
  view('public/report',compact('zones','photoError'));
 }
 flash('success',"Reporte recibido. Tu código es $code"); redirect('/consultar?code='.urlencode($code));
}
function helpForm(): void { $zones=db()->query("SELECT id,name FROM zones WHERE active=1 ORDER BY name")->fetchAll(); view('public/help', compact('zones')); }
function helpStore(): void {
 verify_csrf(); [$latitude,$longitude]=require_location('public/help'); $code=generate_code('AY-BAB');
 $stmt=db()->prepare("INSERT INTO needs_requests(code,zone_id,categories,adults,children,elderly,disabled,can_evacuate,contact_name,contact_phone,description,priority,latitude,longitude,status,verification,requested_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'received','citizen',NOW())");
 $stmt->execute([$code,$_POST['zone_id']?:null,json_encode($_POST['categories']??[],JSON_UNESCAPED_UNICODE),(int)($_POST['adults']??0),(int)($_POST['children']??0),(int)($_POST['elderly']??0),(int)($_POST['disabled']??0),$_POST['can_evacuate']??'unknown',trim($_POST['contact_name']??''),trim($_POST['contact_phone']??''),trim($_POST['description']??''),$_POST['priority']??'normal',$latitude,$longitude]);
 $id=(int)db()->lastInsertId(); db()->prepare("INSERT INTO report_updates(needs_request_id,to_status,comment,created_at) VALUES(?,'received','Solicitud recibida',NOW())")->execute([$id]);
 flash('success',"Solicitud recibida. Tu código es $code"); redirect('/consultar?code='.urlencode($code));
}
function trackForm(): void { $result=null; $history=[]; if (!empty($_GET['code'])) { $_POST['code']=$_GET['code']; track(false); return; } view('public/track',compact('result','history')); }
function track(bool $verify=true): void {
 if ($verify && ($_SERVER['REQUEST_METHOD']??'GET')==='POST') verify_csrf();
 $code=trim($_POST['code']??$_GET['code']??''); $result=null; $history=[];
 if (str_starts_with($code,'CR-')) { $s=db()->prepare("SELECT r.*,z.name zone_name FROM reports r LEFT JOIN zones z ON z.id=r.zone_id WHERE r.code=?"); $s->execute([$code]); $result=$s->fetch(); if($result){$h=db()->prepare("SELECT * FROM report_updates WHERE report_id=? ORDER BY created_at");$h->execute([$result['id']]);$history=$h->fetchAll();}}
 elseif(str_starts_with($code,'AY-')){$s=db()->prepare("SELECT n.*,z.name zone_name FROM needs_requests n LEFT JOIN zones z ON z.id=n.zone_id WHERE n.code=?");$s->execute([$code]);$result=$s->fetch();if($result){$h=db()->prepare("SELECT * FROM report_updates WHERE needs_request_id=? ORDER BY created_at");$h->execute([$result['id']]);$history=$h->fetchAll();}}
 view('public/track',compact('result','history','code'));
}
function alerts(): void { $alerts=db()->query("SELECT * FROM alerts WHERE active=1 AND starts_at<=NOW() AND (ends_at IS NULL OR ends_at>=NOW()) ORDER BY starts_at DESC")->fetchAll(); view('public/alerts',compact('alerts')); }
function points(): void { $points=db()->query("SELECT ap.*,z.name zone_name FROM assistance_points ap LEFT JOIN zones z ON z.id=ap.zone_id WHERE ap.active=1 ORDER BY ap.name")->fetchAll(); view('public/points',compact('points')); }
function map(): void {
 $reports=db()->query("SELECT r.code,r.hazard,r.severity,r.status,r.verification,r.description,r.reported_at,z.name zone_name,COALESCE(r.latitude,z.latitude) latitude,COALESCE(r.longitude,z.longitude) longitude FROM reports r LEFT JOIN zones z ON z.id=r.zone_id WHERE r.status NOT IN ('duplicate','cancelled','unverifiable') AND COALESCE(r.latitude,z.latitude) IS NOT NULL AND COALESCE(r.longitude,z.longitude) IS NOT NULL ORDER BY r.reported_at DESC LIMIT 200")->fetchAll();
 $needs=db()->query("SELECT n.code,n.categories,n.priority,n.status,n.verification,n.description,n.adults,n.children,n.elderly,n.disabled,n.requested_at,z.name zone_name,COALESCE(n.latitude,z.latitude) latitude,COALESCE(n.longitude,z.longitude) longitude FROM needs_requests n LEFT JOIN zones z ON z.id=n.zone_id WHERE n.status NOT IN ('duplicate','cancelled','unverifiable','closed') AND COALESCE(n.latitude,z.latitude) IS NOT NULL AND COALESCE(n.longitude,z.longitude) IS NOT NULL ORDER BY n.requested_at DESC LIMIT 200")->fetchAll();
 view('public/map',compact('reports','needs'));
}
function loginForm(): void { view('auth/login'); }
function login(): void { verify_csrf(); $s=db()->prepare("SELECT u.*,o.name organization_name FROM users u LEFT JOIN organizations o ON o.id=u.organization_id WHERE u.email=? AND u.active=1 LIMIT 1");$s->execute([trim($_POST['email']??'')]);$u=$s->fetch(); if(!$u||!password_verify($_POST['password']??'',$u['password_hash'])){flash('error','Credenciales inválidas.');redirect('/login');} unset($u['password_hash']);$_SESSION['user']=$u;redirect('/panel'); }
function logout(): void { session_destroy(); redirect('/'); }
function dashboard(): void { require_auth(); $stats=['reports'=>(int)db()->query("SELECT COUNT(*) FROM reports")->fetchColumn(),'needs'=>(int)db()->query("SELECT COUNT(*) FROM needs_requests")->fetchColumn(),'verified'=>(int)db()->query("SELECT COUNT(*) FROM reports WHERE verification IN ('verified','official')")->fetchColumn(),'alerts'=>(int)db()->query("SELECT COUNT(*) FROM alerts WHERE active=1")->fetchColumn()]; view('panel/dashboard',compact('stats')); }
function panelReports(): void { require_auth();$rows=db()->query("SELECT r.*,z.name zone_name FROM reports r LEFT JOIN zones z ON z.id=r.zone_id ORDER BY reported_at DESC LIMIT 200")->fetchAll();view('panel/reports',compact('rows')); }
function panelNeeds(): void { require_auth();$rows=db()->query("SELECT n.*,z.name zone_name,o.name organization_name FROM needs_requests n LEFT JOIN zones z ON z.id=n.zone_id LEFT JOIN organizations o ON o.id=n.assigned_organization_id ORDER BY requested_at DESC LIMIT 200")->fetchAll();view('panel/needs',compact('rows')); }

function require_location(string $template): array {
 $lat=filter_var($_POST['latitude']??null,FILTER_VALIDATE_FLOAT);
 $lng=filter_var($_POST['longitude']??null,FILTER_VALIDATE_FLOAT);
 if($lat===false || $lng===false || $lat===null || $lng===null || !is_finite($lat) || !is_finite($lng) || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 || empty($_POST['location_confirmed'])){
  http_response_code(422);
  $zones=db()->query("SELECT id,name FROM zones WHERE active=1 ORDER BY name")->fetchAll();
  $locationError='Obtén tu ubicación y confirma que corresponde al lugar del caso antes de enviar.';
  view($template,compact('zones','locationError'));
 }
 return [$lat,$lng];
}
