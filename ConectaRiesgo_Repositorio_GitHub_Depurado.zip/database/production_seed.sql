-- Ejecutar DESPUÉS de schema.sql dentro de la base seleccionada en phpMyAdmin.
-- Datos territoriales iniciales. No incluye reportes, solicitudes ni usuarios ficticios.

INSERT INTO zones(name,code,level,latitude,longitude) VALUES
('Babahoyo','EC-LR-BAB','canton',-1.8022,-79.5344),
('El Salto','EC-LR-BAB-ELS','sector',-1.8133,-79.5468),
('Barreiro','EC-LR-BAB-BAR','sector',-1.7910,-79.5218),
('Pimocha','EC-LR-BAB-PIM','parish',-1.7401,-79.5670),
('Caracol','EC-LR-BAB-CAR','parish',-1.7552,-79.5948)
ON DUPLICATE KEY UPDATE name=VALUES(name), level=VALUES(level), latitude=VALUES(latitude), longitude=VALUES(longitude), active=1;

INSERT INTO organizations(name,type,verified,description,contact_email,active) VALUES
('Fundación Misión E Tech','foundation',1,'Organización impulsora de ConectaRiesgo.',NULL,1),
('De Aquí +','social_enterprise',1,'Aporte tecnológico a ConectaRiesgo.',NULL,1);
