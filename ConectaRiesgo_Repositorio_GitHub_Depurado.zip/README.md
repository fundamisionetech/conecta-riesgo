# ConectaRiesgo

**Tecnología abierta para comunidades más resilientes.**

ConectaRiesgo es una iniciativa de **Fundación Misión E TECH** con participación de **co/amplIA** que busca facilitar reportes ciudadanos de afectaciones, solicitudes de ayuda y visualización de información territorial durante situaciones de riesgo, inicialmente con énfasis en inundaciones.

> **Aviso importante:** Este repositorio representa un desarrollo en evolución. No sustituye los canales ni los servicios oficiales de emergencia. No utilices la aplicación para la atención de casos reales sin pruebas, protocolo institucional, medidas de seguridad y responsables definidos.

## Tecnologías

- PHP 8.2 (aplicación y rutas en `index.php`)
- MySQL / MariaDB (PDO con `pdo_mysql`)
- Apache con `mod_rewrite` y HTTPS
- Extensiones PHP: `pdo_mysql`, `fileinfo` y `gd` (para fotografías)

## Estructura

```text
index.php                  Punto de entrada de la aplicación
app/                       Configuración y vistas PHP
assets/                    CSS, JavaScript y logos
storage/                   Logs y fotografías generadas (no se publican)
database/schema.sql        Esquema de la base de datos
database/production_seed.sql Datos iniciales del territorio de ejemplo
.env.example               Plantilla de configuración SIN credenciales
.htaccess                  Reglas de servidor Apache
```

## Instalación rápida (instancia de prueba)

1. Prepara un servidor con PHP 8.2 o compatible, MySQL/MariaDB, HTTPS y Apache con reescritura de URLs.
2. Crea una base de datos y un usuario con permisos limitados a esa base.
3. Importa primero `database/schema.sql` y después `database/production_seed.sql` en phpMyAdmin.
4. Copia `.env.example` a `.env` **solo en el servidor** y configura URL, conexión a la base de datos y datos territoriales. **No subas `.env` a GitHub.**
5. Copia el contenido de este proyecto al directorio raíz del subdominio (no una carpeta adicional llamada `conectariesgo.misionetech.org`).
6. Otorga permisos de escritura al usuario del servidor en `storage/logs` y `storage/uploads/reports`; conserva las reglas que restringen su acceso público.
7. Crea una cuenta administradora de forma segura mediante un hash generado con `password_hash()` (no hay un asistente de instalación de administradores incluido en esta entrega).
8. Prueba la página principal, el registro de reportes, el envío de fotografías, la geolocalización, el seguimiento y el acceso institucional en un ambiente de prueba.

La base inicial incluye registros territoriales de referencia para **Babahoyo, Los Ríos**. Adáptalos antes de desplegar en otro territorio.

## Antes de un despliegue real

- Validar los permisos, la autenticación y los formularios de extremo a extremo.
- Garantizar procesos de revisión, escalamiento, resguardo y eliminación de datos personales.
- Revisar legislación aplicable y protocolos de gestión de riesgos y protección de datos.
- No almacenar credenciales, fotografías de usuarios ni registros de errores en Git.
- Rotar las credenciales reales que aparecieron en archivos o copias previamente distribuidas.
- Comprobar que el servidor no exponga archivos internos ni de configuración.

## Licencia

**Pendiente de definición.** La visibilidad pública en GitHub no otorga automáticamente permisos para reutilizar, modificar o distribuir el código. Antes de distribuir esta iniciativa como *open source*, la organización responsable debe revisar sus derechos sobre el código y los recursos gráficos y publicar una licencia explícita.

## Créditos

**Fundación Misión E TECH** · Iniciativa de innovación social.  
**co/amplIA** · Colaboración tecnológica.  

