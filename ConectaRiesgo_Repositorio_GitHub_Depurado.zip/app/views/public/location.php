<fieldset class="gps-location">
<legend>Ubicación del caso</legend>
<p>Ubícate en el lugar de la afectación o de la solicitud. Permite el acceso a la ubicación del dispositivo. El punto registrado aparecerá en el mapa público.</p>
<?php if(!empty($locationError)):?><p role="alert"><?=e($locationError)?></p><?php endif;?>
<button type="button" class="btn" data-get-location>Usar mi ubicación actual</button>
<p data-location-status role="status" aria-live="polite">Aún no se ha obtenido la ubicación.</p>
<input type="hidden" name="latitude"><input type="hidden" name="longitude">
<label><input type="checkbox" name="location_confirmed" value="1" required disabled> Confirmo que esta ubicación corresponde al lugar del caso.</label>
<p>La precisión depende del dispositivo y de la señal. En computadoras puede ser aproximada. Si existe peligro inmediato, llama al 911.</p>
<noscript>Activa JavaScript para obtener la ubicación y enviar el formulario.</noscript>
</fieldset>
