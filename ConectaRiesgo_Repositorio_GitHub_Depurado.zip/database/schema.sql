CREATE TABLE zones (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  code VARCHAR(60) NOT NULL UNIQUE,
  level ENUM('country','province','canton','parish','sector') NOT NULL,
  parent_id BIGINT UNSIGNED NULL,
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_zone_parent FOREIGN KEY(parent_id) REFERENCES zones(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE organizations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  type VARCHAR(60) NOT NULL,
  verified TINYINT(1) NOT NULL DEFAULT 0,
  description TEXT NULL,
  contact_email VARCHAR(180) NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(160) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','institution','verifier') NOT NULL,
  organization_id BIGINT UNSIGNED NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_user_org FOREIGN KEY(organization_id) REFERENCES organizations(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE reports (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(80) NOT NULL UNIQUE,
  hazard ENUM('flood','landslide','fire','earthquake','drought','other') NOT NULL DEFAULT 'flood',
  zone_id BIGINT UNSIGNED NULL,
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  accuracy DECIMAL(8,2) NULL,
  location_method ENUM('gps','map','sector') NULL,
  severity ENUM('none','light','moderate','severe','critical') NOT NULL,
  indicators JSON NOT NULL,
  water_level VARCHAR(50) NULL,
  description TEXT NULL,
  photo_path VARCHAR(255) NULL,
  status ENUM('received','pending_verification','verified','assigned','help_on_way','attended','closed','duplicate','unverifiable','cancelled') NOT NULL DEFAULT 'pending_verification',
  verification ENUM('citizen','in_verification','verified','official') NOT NULL DEFAULT 'citizen',
  related_report_id BIGINT UNSIGNED NULL,
  device_hash VARCHAR(128) NULL,
  reported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  verified_at DATETIME NULL,
  verified_by BIGINT UNSIGNED NULL,
  closed_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_reports_zone(zone_id), INDEX idx_reports_time(reported_at),
  CONSTRAINT fk_report_zone FOREIGN KEY(zone_id) REFERENCES zones(id) ON DELETE SET NULL,
  CONSTRAINT fk_related_report FOREIGN KEY(related_report_id) REFERENCES reports(id) ON DELETE SET NULL,
  CONSTRAINT fk_report_verifier FOREIGN KEY(verified_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE needs_requests (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(80) NOT NULL UNIQUE,
  zone_id BIGINT UNSIGNED NULL,
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  accuracy DECIMAL(8,2) NULL,
  categories JSON NOT NULL,
  adults INT UNSIGNED NOT NULL DEFAULT 0,
  children INT UNSIGNED NOT NULL DEFAULT 0,
  elderly INT UNSIGNED NOT NULL DEFAULT 0,
  disabled INT UNSIGNED NOT NULL DEFAULT 0,
  can_evacuate ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  contact_name VARCHAR(160) NULL,
  contact_phone VARCHAR(40) NULL,
  description TEXT NULL,
  priority ENUM('normal','high','critical') NOT NULL DEFAULT 'normal',
  status ENUM('received','pending_verification','verified','assigned','help_on_way','attended','closed','duplicate','unverifiable','cancelled') NOT NULL DEFAULT 'received',
  verification ENUM('citizen','in_verification','verified','official') NOT NULL DEFAULT 'citizen',
  report_id BIGINT UNSIGNED NULL,
  assigned_organization_id BIGINT UNSIGNED NULL,
  device_hash VARCHAR(128) NULL,
  requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  verified_at DATETIME NULL,
  assigned_at DATETIME NULL,
  attended_at DATETIME NULL,
  closed_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_need_zone(zone_id), INDEX idx_need_time(requested_at),
  CONSTRAINT fk_need_zone FOREIGN KEY(zone_id) REFERENCES zones(id) ON DELETE SET NULL,
  CONSTRAINT fk_need_report FOREIGN KEY(report_id) REFERENCES reports(id) ON DELETE SET NULL,
  CONSTRAINT fk_need_org FOREIGN KEY(assigned_organization_id) REFERENCES organizations(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE report_updates (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  report_id BIGINT UNSIGNED NULL,
  needs_request_id BIGINT UNSIGNED NULL,
  from_status VARCHAR(40) NULL,
  to_status VARCHAR(40) NOT NULL,
  comment VARCHAR(500) NULL,
  user_id BIGINT UNSIGNED NULL,
  organization_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_update_report FOREIGN KEY(report_id) REFERENCES reports(id) ON DELETE CASCADE,
  CONSTRAINT fk_update_need FOREIGN KEY(needs_request_id) REFERENCES needs_requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_update_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_update_org FOREIGN KEY(organization_id) REFERENCES organizations(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE verification_records (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  report_id BIGINT UNSIGNED NULL,
  needs_request_id BIGINT UNSIGNED NULL,
  verifier_id BIGINT UNSIGNED NULL,
  method ENUM('photo','call','visit','multiple_reports','institutional') NOT NULL,
  result ENUM('citizen','in_verification','verified','official') NOT NULL,
  notes TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ver_report FOREIGN KEY(report_id) REFERENCES reports(id) ON DELETE CASCADE,
  CONSTRAINT fk_ver_need FOREIGN KEY(needs_request_id) REFERENCES needs_requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_ver_user FOREIGN KEY(verifier_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE case_assignments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  needs_request_id BIGINT UNSIGNED NOT NULL,
  organization_id BIGINT UNSIGNED NOT NULL,
  assigned_by BIGINT UNSIGNED NULL,
  responsible_name VARCHAR(160) NULL,
  notes TEXT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_assignment_need FOREIGN KEY(needs_request_id) REFERENCES needs_requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_assignment_org FOREIGN KEY(organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
  CONSTRAINT fk_assignment_user FOREIGN KEY(assigned_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE alerts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  source VARCHAR(180) NOT NULL,
  is_official TINYINT(1) NOT NULL DEFAULT 0,
  level ENUM('informative','caution','alert','emergency') NOT NULL DEFAULT 'informative',
  zone_ids JSON NULL,
  starts_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ends_at DATETIME NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  organization_id BIGINT UNSIGNED NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_alert_org FOREIGN KEY(organization_id) REFERENCES organizations(id) ON DELETE SET NULL,
  CONSTRAINT fk_alert_user FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE assistance_points (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  type VARCHAR(80) NOT NULL,
  zone_id BIGINT UNSIGNED NULL,
  address VARCHAR(250) NULL,
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  schedule VARCHAR(160) NULL,
  services JSON NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  organization_id BIGINT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_point_zone FOREIGN KEY(zone_id) REFERENCES zones(id) ON DELETE SET NULL,
  CONSTRAINT fk_point_org FOREIGN KEY(organization_id) REFERENCES organizations(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE humanitarian_deliveries (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(80) NOT NULL UNIQUE,
  organization_id BIGINT UNSIGNED NULL,
  destination_zone_id BIGINT UNSIGNED NULL,
  status ENUM('preparing','dispatched','en_route','delivering','delivered') NOT NULL DEFAULT 'preparing',
  responsible_name VARCHAR(160) NULL,
  notes TEXT NULL,
  dispatched_at DATETIME NULL,
  delivered_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_del_org FOREIGN KEY(organization_id) REFERENCES organizations(id) ON DELETE SET NULL,
  CONSTRAINT fk_del_zone FOREIGN KEY(destination_zone_id) REFERENCES zones(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE delivery_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  delivery_id BIGINT UNSIGNED NOT NULL,
  item_name VARCHAR(160) NOT NULL,
  quantity DECIMAL(10,2) NOT NULL DEFAULT 0,
  unit VARCHAR(50) NOT NULL,
  CONSTRAINT fk_item_delivery FOREIGN KEY(delivery_id) REFERENCES humanitarian_deliveries(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE activities_4w (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  organization_id BIGINT UNSIGNED NULL,
  zone_id BIGINT UNSIGNED NULL,
  category VARCHAR(100) NOT NULL,
  activity VARCHAR(220) NOT NULL,
  target_population VARCHAR(180) NULL,
  status ENUM('planned','in_progress','finished') NOT NULL DEFAULT 'planned',
  starts_at DATE NULL,
  ends_at DATE NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_4w_org FOREIGN KEY(organization_id) REFERENCES organizations(id) ON DELETE SET NULL,
  CONSTRAINT fk_4w_zone FOREIGN KEY(zone_id) REFERENCES zones(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE activity_log (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  action VARCHAR(180) NOT NULL,
  entity_type VARCHAR(80) NULL,
  entity_id BIGINT UNSIGNED NULL,
  metadata JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_log_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
