<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);
$envFile = $root . '/.env';
if (is_file($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key, $value] = array_map('trim', explode('=', $line, 2));
        $value = trim($value, "\"'");
        $_ENV[$key] = $value;
    }
}

function env(string $key, ?string $default = null): ?string {
    return $_ENV[$key] ?? getenv($key) ?: $default;
}

$isProduction = env('APP_ENV', 'production') === 'production';
ini_set('display_errors', $isProduction ? '0' : '1');
ini_set('display_startup_errors', $isProduction ? '0' : '1');
error_reporting(E_ALL);
if ($isProduction) {
    ini_set('log_errors', '1');
    ini_set('error_log', $root . '/storage/logs/php-error.log');
}

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_name('conectariesgo_session');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => $isHttps,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

function db(): PDO {
    static $pdo;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        env('DB_HOST','localhost'), env('DB_PORT','3306'), env('DB_NAME','')
    );
    $pdo = new PDO($dsn, env('DB_USER',''), env('DB_PASS',''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function view(string $name, array $data = []): never {
    extract($data, EXTR_SKIP);
    $view = dirname(__DIR__) . '/views/' . $name . '.php';
    if (!is_file($view)) { http_response_code(500); exit('Vista no encontrada'); }
    require dirname(__DIR__) . '/views/layouts/header.php';
    require $view;
    require dirname(__DIR__) . '/views/layouts/footer.php';
    exit;
}

function base_path(): string {
    $configured = trim((string)env('APP_BASE_PATH',''));
    if ($configured !== '') return '/' . trim($configured, '/');
    return '';
}
function url(string $path = '/'): string {
    $path = '/' . ltrim($path, '/');
    return base_path() . ($path === '/' ? '/' : $path);
}
function redirect(string $to): never {
    if (preg_match('~^https?://~i', $to)) { header('Location: ' . $to); exit; }
    $parts = parse_url($to);
    $path = $parts['path'] ?? '/';
    $target = url($path);
    if (isset($parts['query'])) $target .= '?' . $parts['query'];
    if (isset($parts['fragment'])) $target .= '#' . $parts['fragment'];
    header('Location: ' . $target, true, 302); exit;
}
function e(?string $value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(): void { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['_token'] ?? '')) { http_response_code(419); exit('Sesión expirada.'); } }
function auth_user(): ?array { return $_SESSION['user'] ?? null; }
function require_auth(): void { if (!auth_user()) redirect('/login'); }
function flash(string $key, ?string $value = null): ?string { if ($value !== null) { $_SESSION['_flash'][$key]=$value; return null; } $v=$_SESSION['_flash'][$key]??null; unset($_SESSION['_flash'][$key]); return $v; }
function generate_code(string $prefix): string { return $prefix . '-' . date('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)),0,6)); }
