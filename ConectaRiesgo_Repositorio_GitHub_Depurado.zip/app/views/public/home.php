<section class="hero"><div><span class="eyebrow">INNOVACIÓN SOCIAL · RESILIENCIA TERRITORIAL</span><h1>Tecnología abierta para comunidades más resilientes.</h1><p>ConectaRiesgo conecta ciudadanía, territorio e instituciones durante emergencias para facilitar reportes comunitarios, verificación, coordinación de necesidades y seguimiento de la respuesta.</p><div class="actions"><a class="btn primary" href="<?=e(url('/reportar'))?>">Ingresar / Probar plataforma</a><a class="btn" href="<?=e(url('/recursos'))?>">Ver código y recursos</a></div></div><div class="hero-card"><h3>¿Qué puedes hacer?</h3><div class="step"><b>01</b><span>Reportar lo que ocurre en tu sector</span></div><div class="step"><b>02</b><span>Solicitar ayuda y dar seguimiento</span></div><div class="step"><b>03</b><span>Consultar alertas y puntos de apoyo</span></div><div class="step"><b>04</b><span>Apoyar una respuesta coordinada</span></div></div></section>

<style>
.cr-partners{margin:24px auto 36px;padding:32px 24px;background:#fff;text-align:center;width:100%;box-sizing:border-box}
.cr-partners-logos{display:flex;align-items:center;justify-content:center;gap:56px;max-width:600px;margin:0 auto;flex-wrap:wrap}
.cr-partner-frame{display:flex;align-items:center;justify-content:center;flex:0 0 220px;height:180px;overflow:hidden}
.cr-partner-logo{display:block;object-fit:contain}
.cr-partner-logo--mission{width:140px;height:158px}
.cr-partner-logo--deaqui{width:220px;height:220px;flex-shrink:0}
@media(max-width:540px){.cr-partners{padding:24px 12px}.cr-partners-logos{gap:20px}.cr-partner-frame{flex-basis:140px;height:150px}.cr-partner-logo--mission{width:115px;height:130px}.cr-partner-logo--deaqui{width:170px;height:170px}}
</style>
<section class="cr-partners" aria-label="Organizaciones impulsoras de ConectaRiesgo">
<div class="cr-partners-logos">
<div class="cr-partner-frame"><img class="cr-partner-logo cr-partner-logo--mission" src="<?=e(url('/assets/img/mision-e-tech.png'))?>" alt="Fundación Misión E Tech"></div>
<div class="cr-partner-frame"><img class="cr-partner-logo cr-partner-logo--deaqui" src="<?=e(url('/assets/img/coamplia.jpeg'))?>" alt="co/amplia"></div>
</div>
</section>

<section class="section"><span class="eyebrow">QUÉ ES Y PARA QUÉ NACE</span><h2>De información dispersa a una visión territorial útil.</h2><p class="lead">Durante una emergencia, los datos pueden quedar repartidos entre llamadas, mensajes, redes sociales y distintas instituciones. ConectaRiesgo ayuda a ordenar esa información para apoyar decisiones y coordinación humanitaria.</p><div class="grid3"><article class="card"><h3>Reportar</h3><p>La comunidad registra afectaciones y necesidades sin publicar datos personales.</p></article><article class="card"><h3>Verificar</h3><p>Equipos autorizados revisan el origen, confiabilidad y evolución de cada caso.</p></article><article class="card"><h3>Coordinar</h3><p>Instituciones organizan asignaciones, respuesta, ayuda en camino y cierre.</p></article></div></section>
<section class="section dark"><span class="eyebrow">OPEN SOURCE Y REPLICABILIDAD</span><h2>Usa, adapta y replica ConectaRiesgo.</h2><p>El núcleo está pensado para que municipios, universidades, organizaciones, desarrolladores y comunidades puedan desplegar nuevas instancias territoriales.</p><a class="btn light" href="<?=e(url('/recursos'))?>">Explorar recursos</a></section>
<section class="section"><h2>¿Quieres implementar ConectaRiesgo en tu territorio?</h2><p class="lead">La tecnología puede implementarse de forma autónoma o con acompañamiento especializado.</p><a class="btn primary" href="mailto:contacto@example.org">Conversemos</a></section>
