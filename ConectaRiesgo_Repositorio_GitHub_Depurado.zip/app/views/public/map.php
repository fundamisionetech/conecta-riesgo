<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<section class="page wide map-page">
  <span class="eyebrow">MAPA TERRITORIAL</span>
  <h1>Afectaciones y solicitudes de ayuda</h1>
  <p class="lead map-lead">Explora los registros activos de ConectaRiesgo. Puedes visualizar las afectaciones reportadas, las solicitudes de ayuda o ambas capas al mismo tiempo.</p>

  <div class="map-toolbar" role="group" aria-label="Capas del mapa">
    <button type="button" class="map-filter active" data-layer="all">
      <span class="filter-dot both"></span> Ver todo
      <strong><?=count($reports)+count($needs)?></strong>
    </button>
    <button type="button" class="map-filter" data-layer="reports">
      <span class="filter-dot affected"></span> Afectaciones
      <strong><?=count($reports)?></strong>
    </button>
    <button type="button" class="map-filter" data-layer="needs">
      <span class="filter-dot help"></span> Solicitudes de ayuda
      <strong><?=count($needs)?></strong>
    </button>
  </div>

  <div class="map-legend">
    <span><i class="legend-marker affected"></i> Afectación registrada</span>
    <span><i class="legend-marker help"></i> Solicitud de ayuda</span>
    <span class="map-privacy">Las ubicaciones públicas muestran la coordenada registrada o, cuando no existe, el punto de referencia del sector.</span>
  </div>

  <div id="map"></div>

  <div class="map-summary">
    <div><b id="visibleReports"><?=count($reports)?></b><span>Afectaciones visibles</span></div>
    <div><b id="visibleNeeds"><?=count($needs)?></b><span>Solicitudes visibles</span></div>
  </div>
</section>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const map = L.map('map').setView([<?=e(env('MAP_LAT','-1.8022'))?>, <?=e(env('MAP_LNG','-79.5344'))?>], <?=e(env('MAP_ZOOM','12'))?>);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap',
  maxZoom: 19
}).addTo(map);

const reports = <?=json_encode($reports, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?>;
const needs = <?=json_encode($needs, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?>;
const reportLayer = L.layerGroup().addTo(map);
const needsLayer = L.layerGroup().addTo(map);
const bounds = [];

const esc = (v='') => String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));
const labels = {
  none:'Sin afectación', light:'Leve', moderate:'Moderada', severe:'Severa', critical:'Crítica',
  normal:'Normal', high:'Alta', received:'Recibida', pending_verification:'Pendiente de verificación',
  verified:'Verificada', assigned:'Asignada', help_on_way:'Ayuda en camino', attended:'Atendida', closed:'Cerrada',
  citizen:'Registro ciudadano', in_verification:'En verificación', official:'Oficial',
  water:'Agua', food:'Alimentos', medicine:'Medicinas', shelter:'Alojamiento', evacuation:'Evacuación', rescue:'Rescate', hygiene:'Higiene'
};
const label = v => labels[v] || String(v || '').replaceAll('_',' ');
const parseCats = value => {
  try { const a = Array.isArray(value) ? value : JSON.parse(value || '[]'); return a.map(label).join(', ') || 'Sin categoría'; }
  catch(e) { return 'Sin categoría'; }
};

reports.forEach(r => {
  const lat = Number(r.latitude), lng = Number(r.longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
  const marker = L.circleMarker([lat,lng], {
    radius: 9, color: '#a53d2c', weight: 3, fillColor: '#e35f47', fillOpacity: .9
  }).bindPopup(`
    <div class="map-popup">
      <span class="popup-type affected">Afectación</span>
      <h3>${esc(r.zone_name || 'Sector registrado')}</h3>
      <p><b>Código:</b> ${esc(r.code)}</p>
      <p><b>Severidad:</b> ${esc(label(r.severity))}</p>
      <p><b>Estado:</b> ${esc(label(r.status))}</p>
      <p><b>Verificación:</b> ${esc(label(r.verification))}</p>
      ${r.description ? `<p class="popup-description">${esc(r.description)}</p>` : ''}
      <a class="popup-link" href="<?=e(url('/consultar'))?>?code=${encodeURIComponent(r.code)}">Ver seguimiento →</a>
    </div>`);
  marker.addTo(reportLayer); bounds.push([lat,lng]);
});

needs.forEach(n => {
  const lat = Number(n.latitude), lng = Number(n.longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
  const affectedPeople = Number(n.adults||0)+Number(n.children||0)+Number(n.elderly||0)+Number(n.disabled||0);
  const marker = L.circleMarker([lat,lng], {
    radius: 9, color: '#145884', weight: 3, fillColor: '#2f8fc5', fillOpacity: .9
  }).bindPopup(`
    <div class="map-popup">
      <span class="popup-type help">Solicitud de ayuda</span>
      <h3>${esc(n.zone_name || 'Sector registrado')}</h3>
      <p><b>Código:</b> ${esc(n.code)}</p>
      <p><b>Necesidad:</b> ${esc(parseCats(n.categories))}</p>
      <p><b>Prioridad:</b> ${esc(label(n.priority))}</p>
      <p><b>Estado:</b> ${esc(label(n.status))}</p>
      ${affectedPeople ? `<p><b>Personas registradas:</b> ${affectedPeople}</p>` : ''}
      ${n.description ? `<p class="popup-description">${esc(n.description)}</p>` : ''}
      <a class="popup-link" href="<?=e(url('/consultar'))?>?code=${encodeURIComponent(n.code)}">Ver seguimiento →</a>
    </div>`);
  marker.addTo(needsLayer); bounds.push([lat,lng]);
});

if (bounds.length > 1) map.fitBounds(bounds, {padding:[35,35], maxZoom:14});
else if (bounds.length === 1) map.setView(bounds[0], 14);

function setLayer(mode) {
  if (map.hasLayer(reportLayer)) map.removeLayer(reportLayer);
  if (map.hasLayer(needsLayer)) map.removeLayer(needsLayer);
  if (mode === 'all' || mode === 'reports') reportLayer.addTo(map);
  if (mode === 'all' || mode === 'needs') needsLayer.addTo(map);
  document.getElementById('visibleReports').textContent = mode === 'needs' ? '0' : reports.length;
  document.getElementById('visibleNeeds').textContent = mode === 'reports' ? '0' : needs.length;
  document.querySelectorAll('.map-filter').forEach(b => b.classList.toggle('active', b.dataset.layer === mode));
}

document.querySelectorAll('.map-filter').forEach(btn => btn.addEventListener('click', () => setLayer(btn.dataset.layer)));
</script>
